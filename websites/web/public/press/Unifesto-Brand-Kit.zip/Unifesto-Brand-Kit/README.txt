Unifesto brand kit · Unifesto Horizon · October 2026

Logo/      The wordmark. Silver on dark backgrounds, ink on light. White/black for one-colour use.
Symbol/    The "u" on its own, for avatars and small spaces.
App icon/  The app icon, square (stores apply their own mask) and rounded (for slides and mockups).
Favicon/   Browser and small-size icon.
Social/    Profile picture for social accounts.
Products/  Unifesto Sprint and Unifesto Encore lockups. Same colour rules as the logo.
Powered by/  Badges for events run on Unifesto: boxed dark/light, one-colour white/black, horizontal and stacked.
Backgrounds/ The Horizon sky (orbit hairlines, the horizon line and its blue glow), night and day, for slides and video.

Read Unifesto-Brand-Guidelines.pdf before use. It covers the logo and the Unifesto Horizon theme:
colour, type, lines and light, shade cards and frosted glass. Please don't recolour, stretch or retype the logo.
Questions: support@unifesto.app · www.unifesto.app/press
