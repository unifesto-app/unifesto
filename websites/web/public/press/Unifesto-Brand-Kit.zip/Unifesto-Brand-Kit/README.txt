Unifesto brand kit · October 2026

Logo/      The wordmark. Silver on dark backgrounds, ink on light. White/black for one-colour use.
Symbol/    The "u" on its own, for avatars and small spaces.
App icon/  The app icon, square (stores apply their own mask) and rounded (for slides and mockups).
Favicon/   Browser and small-size icon.
Social/    Profile picture for social accounts.
Products/  Unifesto Stay, Unifesto Huddle and Unifesto Sprint lockups. Same colour rules as the logo.
Usage/     Sample posters: Huddle on session posters, Sprint on hackathon posters (masthead, sign-off, light),
           and organiser posters carrying the Powered by badge.
Powered by/  Badges for events run on Unifesto: boxed dark/light, one-colour white/black, horizontal and stacked.

Read Unifesto-Brand-Guidelines.pdf before use. Please don't recolour, stretch or retype the logo.
Questions: support@unifesto.app · www.unifesto.app/press
